<?php

/* This file is part of the Phalcon Framework.
 *
 * (c) Phalcon Team <team@phalcon.io>
 *
 * For the full copyright and license information, please view the LICENSE.txt
 * file that was distributed with this source code.
 */
namespace Phalcon\Html\Attributes;

/**
 * Phalcon\Html\Attributes\RenderInterface
 *
 * Interface Phalcon\Html\Attributes\RenderInterface
 */
interface RenderInterface
{
    /**
     * Generate a string represetation
     *
     * @return string
     */
    public function render(): string;
}
