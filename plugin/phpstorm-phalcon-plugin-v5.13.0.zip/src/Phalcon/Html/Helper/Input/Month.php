<?php

/* This file is part of the Phalcon Framework.
 *
 * (c) Phalcon Team <team@phalcon.io>
 *
 * For the full copyright and license information, please view the LICENSE.txt
 * file that was distributed with this source code.
 */
namespace Phalcon\Html\Helper\Input;

/**
 * Class Month
 */
class Month extends \Phalcon\Html\Helper\Input\AbstractInput
{
    protected $type = 'month';
}
