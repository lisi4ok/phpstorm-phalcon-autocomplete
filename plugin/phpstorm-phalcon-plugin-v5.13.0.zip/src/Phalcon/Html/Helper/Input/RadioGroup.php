<?php

/* This file is part of the Phalcon Framework.
 *
 * (c) Phalcon Team <team@phalcon.io>
 *
 * For the full copyright and license information, please view the LICENSE.txt
 * file that was distributed with this source code.
 */
namespace Phalcon\Html\Helper\Input;

/**
 * Renders a group of `<input type="radio">` elements from an options array.
 *
 * The $checked parameter should be a single scalar value matching the selected
 * option's value attribute.
 */
class RadioGroup extends \Phalcon\Html\Helper\Input\AbstractGroup
{
    /**
     * @var string
     */
    protected $type = 'radio';

    /**
     * Returns true when $value loosely equals the checked scalar.
     *
     * @param string $value
     *
     * @return bool
     */
    protected function isChecked(string $value): bool
    {
    }
}
