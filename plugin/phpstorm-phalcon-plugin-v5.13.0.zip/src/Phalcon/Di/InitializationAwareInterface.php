<?php

/* This file is part of the Phalcon Framework.
 *
 * (c) Phalcon Team <team@phalcon.io>
 *
 * For the full copyright and license information, please view the LICENSE.txt
 * file that was distributed with this source code.
 */
namespace Phalcon\Di;

/**
 * Interface for components that have `initialize()`
 */
interface InitializationAwareInterface
{
    /**
     * @return void
     */
    public function initialize(): void;
}
